Package Manual
=============


Plane Estimation using Intel Realsense L515 Camera
--------------------------------------------------

# About package
* This package is for plane estimation using Intel Realsense L515 Camera.
* `Date` : 2021.09.20
* `Writer` : jp

## Requirments
* This package is compatible with x86 Desktop and Nvidia Jetson Xavier
* `OS` : Ubuntu 18.04, 64bit, 
* `Jetson` : git clone https://github.com/open-source-parsers/jsoncpp.git 
* `Intel Realsense` : v2.42
* `ROS` : melodic
* `UUV simulator`
* `smarc simulator`

* 
NVIDIA Jetson AGX Xavier [16GB]
 L4T 32.4.4 [ JetPack 4.4.1 ]
   Ubuntu 18.04.5 LTS
   Kernel Version: 4.9.140-tegra
 CUDA 10.2.89
   CUDA Architecture: 7.2
 OpenCV version: 3.4.0
   OpenCV Cuda: YES
 CUDNN: 8.0.0.180
 TensorRT: 7.1.3.0
 Vision Works: 1.6.0.501
 VPI: 0.4.4
 Vulcan: 1.2.70

## Install jsonlib
* git clone https://github.com/open-source-parsers/jsoncpp.git  
* cd ~/your_download_path/jsonlib-master/
* mkdir build
* cmake ..
* make

## Install package
* cd ~/your_catkin_environmnet/src/ 
* git clone https://github.com/kist/service_vision
* cd ~/catkin_ws
* catkin_make

## How to run
* 'roslaunch smarc_auvs upload_example_auv.launch' in terminal.

## Logging
* This package saves the data as image files
- `image files` : sonar images, sonar-synced camera images
- `text-based file` : empty
* Save directories
- `image files` : ~/catkin_ws/src/jisung_simulator/fls_ros_qt_gui/logging
- `text-based file` : same as the case of 'image files'

## Known issues
* 

## Update
* `2021.09.10`: Publishing model occupied region


## To do
* building 'jisung_simulator' package without smarc-simualtor.




