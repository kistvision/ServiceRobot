#ifndef EXAMPLE_ROS_CLASS_H2_
#define EXAMPLE_ROS_CLASS_H2_

#include <iostream>
#include <std_msgs/String.h>
#include <std_msgs/Bool.h>
#include <std_msgs/Float32.h>
#include <json/json.h>
#include <json/value.h>
#include <ros/ros.h>
#include <fstream>
#include <map>
#include <service_operation/PlaneEstimation.h>
#include <math.h>
#include <stdlib.h>
#include <string>
#include <vector>


class ServiceOperation
{
public:
    ServiceOperation(ros::NodeHandle* nodehandle);

private:
    void initializeSubscribers();
    void initializePublishers();
    void leftPoseCallback(const service_operation::PlaneEstimation::ConstPtr& msg);
    void rightPoseCallback(const service_operation::PlaneEstimation::ConstPtr& msg);
    void naviStatusCallback(const std_msgs::String::ConstPtr& msg);
    void cmdMappingNavi(const std_msgs::String::ConstPtr& msg);    

    ros::NodeHandle nh_; 
    ros::Subscriber navi_status_sub, cmd_operation_sub, left_pose_sub, right_pose_sub, sub_left_plane; 
    ros::Publisher cmdGUI, pub_left, pub_right, conaGo_pub;
    geometry_msgs::PoseWithCovariance msgr_left;
    geometry_msgs::PoseWithCovariance msgr_right;
    bool left_status, right_status;
    std::vector<int> readyChecked;
    std::map<std::string, std::string> navistatus;
};

#endif