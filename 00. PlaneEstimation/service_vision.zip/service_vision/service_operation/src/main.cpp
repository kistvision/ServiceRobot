#include <service_operation/service_operation.h>


void ServiceOperation::leftPoseCallback(const service_operation::PlaneEstimation::ConstPtr& msg)
{
  geometry_msgs::PoseWithCovariance msgr;
  msgr.pose.position.x = msg->pose.pose.position.x;
  msgr.pose.position.y = msg->pose.pose.position.y;
  msgr.pose.position.z = msg->pose.pose.position.z;
  msgr.pose.orientation.w = msg->pose.pose.orientation.w;
  msgr.pose.orientation.x = msg->pose.pose.orientation.x;
  msgr.pose.orientation.y = msg->pose.pose.orientation.y;
  msgr.pose.orientation.z = msg->pose.pose.orientation.z;

  for(int i = 0; i < 36; i++)
  {
    msgr.covariance[i] = 1;
  }
  msgr_left = msgr;
  left_status = true;
}


void ServiceOperation::rightPoseCallback(const service_operation::PlaneEstimation::ConstPtr& msg)
{
  geometry_msgs::PoseWithCovariance msgr;
  msgr.pose.position.x = msg->pose.pose.position.x;
  msgr.pose.position.y = msg->pose.pose.position.y;
  msgr.pose.position.z = msg->pose.pose.position.z;
  msgr.pose.orientation.w = msg->pose.pose.orientation.w;
  msgr.pose.orientation.x = msg->pose.pose.orientation.x;
  msgr.pose.orientation.y = msg->pose.pose.orientation.y;
  msgr.pose.orientation.z = msg->pose.pose.orientation.z;

  for(int i = 0; i < 36; i++)
  {
    msgr.covariance[i] = 1;
  }
  msgr_right = msgr;
  right_status = true;
}


void ServiceOperation::cmdMappingNavi(const std_msgs::String::ConstPtr& msg)
{
  Json::Value root;
  std::ifstream cfgfile("/home/ros/catkin_ws/src/service_vision/service_operation/src/cmdMappingNavi.json");
  cfgfile >> root;

  int sizes = root["WayPoints"].size();
  std::string setSpeed = root["Speed"].asString();
  std::string setMap = root["MapName"].asString();

  // set a map
  Json::Value rootMap;
  Json::Value cmdMap;
  cmdMap["cmd"] = "load";
  cmdMap["name"] = setMap.c_str();
  cmdMap["keycmd"] = "non";
  cmdMap["table"] = "non";
  rootMap["cmdMapping"] = cmdMap;
  rootMap["mode"] = "mapping";
  std::string jsonMapMsg = rootMap.toStyledString();
  std_msgs::String rosMapMsg;
  rosMapMsg.data = jsonMapMsg;
  cmdGUI.publish(rosMapMsg);

  sleep(1);

  // set a velocity
  int vel = std::stoi(setSpeed);
  Json::Value rootParam;
  Json::Value cmdParam;
  cmdParam["vel"] = vel;
  rootParam["cmdParam"] = cmdParam;
  rootParam["mode"] = "admin";
  std::string jsonParamMsg = rootParam.toStyledString();
  std_msgs::String rosParamMsg;
  rosParamMsg.data = jsonParamMsg;
  cmdGUI.publish(rosParamMsg);

  sleep(1);

  // set navi
  for (int i = 0; i < sizes; i++)
  {
    Json::Value rootNavi;
    Json::Value goallist;
    Json::Value cmdNavi;
    std::string idx = std::to_string(i);
    std::string nside = root["CameraSide"][i].asString();
    std::string ntarget = root["WayPoints"][i].asString();
    goallist["Table 01"] = ntarget.c_str();
    cmdNavi["cmd"] = "go";
    cmdNavi["goallist"] = goallist;
    rootNavi["cmdNavi"] = cmdNavi;
    rootNavi["mode"] = "navi";    
    std::string jsonNaviMsg = rootNavi.toStyledString();
    std_msgs::String rosNaviMsg;
    rosNaviMsg.data = jsonNaviMsg;
    cmdGUI.publish(rosNaviMsg);

    sleep(1);

    std_msgs::String rosGoMsg;
    std::stringstream ssGo;
    ssGo << "go";
    rosGoMsg.data = ssGo.str();
    conaGo_pub.publish(rosGoMsg);

    sleep(1);

    int onetime = 1;
    readyChecked.at(0) = 0;
    readyChecked.at(1) = 0;
    bool bEstimation = true;
    int request_side = std::stoi(nside);
    while(bEstimation)
    {
      if(readyChecked.at(0) == 1 && readyChecked.at(1) == 1)
	    {
        sleep(0.5);

		    std_msgs::Bool msgJS;
		    msgJS.data = false;

        if(onetime == 1)
        {
          if(request_side == 0)
          {
            pub_left.publish(msgJS);
          }
          else if(request_side == 1)
          {
            pub_right.publish(msgJS);
          }
          else if(request_side == 2)
          {
            pub_left.publish(msgJS);
            pub_right.publish(msgJS);
          }
          onetime = 2;
        }
        if(left_status && right_status)
        {
          bEstimation = false;
	        left_status = false;
	        right_status= false;
        }
      }
    }
  }

  // end navi
  Json::Value rootNavi;
  Json::Value goallist;
  Json::Value cmdNavi;
  cmdNavi["cmd"] = "stop";
  rootNavi["cmdNavi"] = cmdNavi;
  rootNavi["mode"] = "navi";
  std::string jsonNaviMsg = rootNavi.toStyledString();
  std_msgs::String rosNaviMsg;
  rosNaviMsg.data = jsonNaviMsg;
  cmdGUI.publish(rosNaviMsg);

  sleep(1);

  // reset navi
  cmdNavi["cmd"] = "reset";
  rootNavi["cmdNavi"] = cmdNavi;
  rootNavi["mode"] = "navi";    
  jsonNaviMsg = rootNavi.toStyledString();
  rosNaviMsg.data = jsonNaviMsg;
  cmdGUI.publish(rosNaviMsg);   
}


ServiceOperation::ServiceOperation(ros::NodeHandle* nodehandle):nh_(*nodehandle)
{ 
    left_status = false;
    right_status = false;
    readyChecked.push_back(0);
    readyChecked.push_back(0);

    initializeSubscribers();
    initializePublishers();
    
    navistatus.insert(std::pair<std::string, std::string>("ready2work", "non"));
    navistatus.insert(std::pair<std::string, std::string>("status", "non"));
    navistatus.insert(std::pair<std::string, std::string>("to", "non"));
    navistatus.insert(std::pair<std::string, std::string>("next", "non"));
    navistatus.insert(std::pair<std::string, std::string>("type", "non"));        
}


void ServiceOperation::initializeSubscribers()
{
    cmd_operation_sub = nh_.subscribe("/cmdMappingNavi", 1, &ServiceOperation::cmdMappingNavi, this);
    navi_status_sub = nh_.subscribe("/navistatus", 1, &ServiceOperation::naviStatusCallback, this);
    left_pose_sub = nh_.subscribe("/service_vision/camera_left/camera_left/plane_estimation", 1, &ServiceOperation::leftPoseCallback, this);
    right_pose_sub = nh_.subscribe("/service_vision/camera_right/camera_right/plane_estimation", 1, &ServiceOperation::rightPoseCallback, this);
}


void ServiceOperation::initializePublishers()
{
    cmdGUI = nh_.advertise<std_msgs::String>("cmdGUI", 10, true);
    pub_left = nh_.advertise<std_msgs::Bool>("/service_vision/camera_left/depth/request", 5, true);
    pub_right = nh_.advertise<std_msgs::Bool>("/service_vision/camera_right/depth/request", 1, true);
    conaGo_pub = nh_.advertise<std_msgs::String>("/cona/cmd", 5, true);
}


void ServiceOperation::naviStatusCallback(const std_msgs::String::ConstPtr& msg)
{
    std::string ready2work = "ready2work";
    std::string status = "status";
    std::string to = "to";
    std::string next = "next";
    std::string type = "type";
    std::string check_a = "approach";
    std::string check_b = "arrived";

    Json::Reader reader;
    Json::Value root;
    reader.parse(msg->data, root);

    navistatus["ready2work"] = root["ready2work"].asString();
    navistatus["to"] = root["to"].asString();
    navistatus["next"] = root["next"].asString();
    navistatus["type"] = root["type"].asString();
    navistatus["status"] = root["status"].asString();

    std::string check = root["type"].asString();
    if(check == check_a)
    {
      readyChecked.at(0) = 1;
    }
    if(check == check_b)
    {
      readyChecked.at(1) = 1;
    }
}


int main(int argc, char** argv) 
{
    ros::init(argc, argv, "Management");
    ros::NodeHandle nh; 

    ros::AsyncSpinner spinner(5);
    spinner.start();
    ServiceOperation serviceOperationClass(&nh);
    ros::waitForShutdown();

    return 0;
} 
