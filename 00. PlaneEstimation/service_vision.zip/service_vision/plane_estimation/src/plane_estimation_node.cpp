#include <ros/ros.h>
#include <iostream>
#include "plane_estimation_class.h"
#include "sensor_msgs/Imu.h"

using namespace vision_nodelet_ns;


int main(int argc, char **argv)
{
	ros::init(argc, argv, "nodelet_sample_node");
	ros::NodeHandle nh;
    ros::NodeHandle private_nh("~");
	
    ros::AsyncSpinner spinner(5);
    spinner.start();
	PlaneEstimationClass ns;
	ns.init(nh, private_nh);
	ros::waitForShutdown();
	
	return 0;
}
