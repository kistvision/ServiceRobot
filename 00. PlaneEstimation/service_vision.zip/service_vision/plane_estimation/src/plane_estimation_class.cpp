#include "plane_estimation_class.h"

using namespace std;
namespace vision_nodelet_ns
{

PlaneEstimationClass::PlaneEstimationClass()
{
	roll_ = 0.f;
	pitch_ = 0.f;
	yaw_ = 0.f;
	dDebug_ = false;
	fHeight_roi_min_ = 0.f;
	fHeight_roi_max_ = 0.f;
	fSampling_threshold_ = 0;
	nSampling_iteration_ = 0.f;	
	fpoint_z_limit_ = 0.f;
	fTF_b2c_pos_x_ = 0.f;
	fTF_b2c_pos_y_ = 0.f;
	fTF_b2c_pos_z_ = 0.f;
	fTF_b2c_quat_w_ = 0.f;
	fTF_b2c_quat_x_ = 0.f;
	fTF_b2c_quat_y_ = 0.f;
	fTF_b2c_quat_z_ = 0.f;
	fTF_b2c_pos_x_manual_ = 0.f;
	fTF_b2c_pos_y_manual_ = 0.f;
	fTF_b2c_pos_z_manual_ = 0.f;
	fTF_b2c_rot_z_manual_ = 0.f;	
}


PlaneEstimationClass::~PlaneEstimationClass()
{
}


void PlaneEstimationClass::init(ros::NodeHandle &nh, ros::NodeHandle &private_nh)
{
	private_nh.getParam("nodelet_manager", sensor_name_);
	private_nh.getParam("debug", dDebug_);
	private_nh.getParam("height_roi_min", fHeight_roi_min_);
	private_nh.getParam("height_roi_max", fHeight_roi_max_);
	private_nh.getParam("sampling_threshold", fSampling_threshold_);
	private_nh.getParam("sampling_iteration", nSampling_iteration_);	
	private_nh.getParam("point_z_limit", fpoint_z_limit_);	
	private_nh.getParam("tf_b2c_pos_x", fTF_b2c_pos_x_);	
	private_nh.getParam("tf_b2c_pos_y", fTF_b2c_pos_y_);	
	private_nh.getParam("tf_b2c_pos_z", fTF_b2c_pos_z_);	
	private_nh.getParam("tf_b2c_quat_w", fTF_b2c_quat_w_);	
	private_nh.getParam("tf_b2c_quat_x", fTF_b2c_quat_x_);	
	private_nh.getParam("tf_b2c_quat_y", fTF_b2c_quat_y_);	
	private_nh.getParam("tf_b2c_quat_z", fTF_b2c_quat_z_);	
	private_nh.getParam("tf_b2c_pos_x_manual", fTF_b2c_pos_x_manual_);	
	private_nh.getParam("tf_b2c_pos_y_manual", fTF_b2c_pos_y_manual_);	
	private_nh.getParam("tf_b2c_pos_z_manual", fTF_b2c_pos_z_manual_);	
	private_nh.getParam("tf_b2c_rot_z_manual", fTF_b2c_rot_z_manual_);

    image_transport::ImageTransport it(nh);
	pubImage_ = it.advertise(sensor_name_ + "/image", 2);
	points_camera_pub_ = nh.advertise<sensor_msgs::PointCloud2> ("points_camera", 10);
	points_robot_pub_ = nh.advertise<sensor_msgs::PointCloud2> ("points_robot", 10);
	points_robot_ransac_pub_ = nh.advertise<sensor_msgs::PointCloud2> ("points_robot_ransac", 10);
	robot_cmd_pub_ = nh.advertise<std_msgs::String> ("cmdGUI", 10);
	estimation_pub_ = nh.advertise<robot_vision::PlaneEstimation>(sensor_name_ + "/plane_estimation", 10);

	extrinsic_sub_ = nh.subscribe<realsense2_camera::Extrinsics>(ros::names::resolve("extrinsics") + "/depth_to_color", 1, boost::bind(&PlaneEstimationClass::extrinsicCallback, this, _1));
	camerainfo_sub_ = nh.subscribe<sensor_msgs::CameraInfo>(ros::names::resolve("color") + "/camera_info", 1, boost::bind(&PlaneEstimationClass::cameraInfoCallback, this, _1));
	tf_static_sub_ = nh.subscribe<tf2_msgs::TFMessage>("/tf_static", 1, boost::bind(&PlaneEstimationClass::staticSubscriptionCallback, this, _1)); 
	image_sub_ = nh.subscribe(ros::names::resolve("color") + "/image_raw", 1, &PlaneEstimationClass::imageCallback, this);
	orientation_filter_sub_ = nh.subscribe(ros::names::resolve("imu") + "/rpy/filtered", 1, &PlaneEstimationClass::orientationFilterCallback, this);
	points_sub_ = nh.subscribe(ros::names::resolve("depth") + "/color/points", 1, &PlaneEstimationClass::pointCloudCallback, this);
	plane_estimation_sub_ = nh.subscribe(ros::names::resolve("depth") + "/request", 5, &PlaneEstimationClass::planeEstimationCallback, this);
}


void PlaneEstimationClass::projectPointToPixel(float pixel[2], std::string *distortion_model, std::vector<float> *intrin_d, std::vector<float> *intrin_k, float point[3])
{
    float x = point[0] / point[2], y = point[1] / point[2];
	
	std::string distortion_plumb_bob("plumb_bob");
	std::string distortion_equidistant("equidistant");

	if(distortion_model->compare(distortion_plumb_bob) == 0)
    {

        float r2  = x*x + y*y;
        float f = 1 + intrin_d->at(0)*r2 + intrin_d->at(1)*r2*r2 + intrin_d->at(4)*r2*r2*r2;
        x *= f;
        y *= f;
        float dx = x + 2*intrin_d->at(2)*x*y + intrin_d->at(3)*(r2 + 2*x*x);
        float dy = y + 2*intrin_d->at(3)*x*y + intrin_d->at(2)*(r2 + 2*y*y);
        x = dx;
        y = dy;
    }
	if (distortion_model->compare(distortion_equidistant) == 0)
    {
        float r = sqrt(x*x + y*y);
        float rd = (1.0f / intrin_d->at(0) * atan(2 * r* tan(intrin_d->at(0) / 2.0f)));
        x *= rd / r;
        y *= rd / r;
    }
    pixel[0] = x * intrin_k->at(0) + intrin_k->at(2);
    pixel[1] = y * intrin_k->at(4) + intrin_k->at(5);
}


void PlaneEstimationClass::transformPointToPoint(float to_point[3], std::vector<float> *pos, std::vector<float> *rot, float from_point[3])
{
    to_point[0] = rot->at(0) * from_point[0] + rot->at(3) * from_point[1] + rot->at(6) * from_point[2] + pos->at(0);
    to_point[1] = rot->at(1) * from_point[0] + rot->at(4) * from_point[1] + rot->at(7) * from_point[2] + pos->at(1);
    to_point[2] = rot->at(2) * from_point[0] + rot->at(5) * from_point[1] + rot->at(8) * from_point[2] + pos->at(2);
}


Eigen::Affine3f PlaneEstimationClass::createRotationMatrix(double ax, double ay, double az)
{
	Eigen::Affine3f rx = Eigen::Affine3f(Eigen::AngleAxisf(ax*M_PI/180.0, Eigen::Vector3f(1, 0, 0)));
	Eigen::Affine3f ry = Eigen::Affine3f(Eigen::AngleAxisf(ay*M_PI/180.0, Eigen::Vector3f(0, 1, 0)));
	Eigen::Affine3f rz = Eigen::Affine3f(Eigen::AngleAxisf(az*M_PI/180.0, Eigen::Vector3f(0, 0, 1)));
	return rz * ry * rx;
}


void PlaneEstimationClass::sampling(pcl::PointCloud<pcl::PointXYZ>::Ptr input,
 pcl::PointCloud<pcl::Normal>::Ptr normal, Eigen::Affine3f i_T_w,
 pcl::PointCloud<pcl::PointXYZ>::Ptr out, pcl::PointCloud<pcl::Normal>::Ptr normal_ransac,
 std::vector<float> *model_eq,
 bool bRansacLog,
 std::vector<Eigen::VectorXi> *setOfRanSacInlierIndex)
{
    // int maxIter = 500;
	// double threshold = 0.09;
	
	Eigen::VectorXf equation(0);
    Eigen::VectorXf best_eq(4);
    Eigen::VectorXi inliers(0);
    Eigen::VectorXi best_inliers(0);

    pcl::PointIndices::Ptr pcl_indices(new pcl::PointIndices());

    for(int i = 0; i < nSampling_iteration_;  i++)
    {
        std::random_device rd;
        std::default_random_engine eng(rd());
        std::uniform_int_distribution<int> distr(0, input->size());
        int index[3] = {-1, -1, -1};
        int m = 0;
        for (int n = 0; m < 3; ++n)
        {
            int test = distr(eng);
            if(m == 0)
            {
                index[0] = test;
                m += 1;
            }
            if(m == 1)
            {
                if(index[0] != test)
                {
                    index[1] = test;
                    m += 1;
                }
            }
            if(m == 2)
            {
                if(index[0] != test && index[1] != test)
                {
                    index[2] = test;
                    m += 1;
                }
            }
        }  

        Eigen::Vector3f pt1(input->points[index[0]].x, input->points[index[0]].y, input->points[index[0]].z);
        Eigen::Vector3f pt2(input->points[index[1]].x, input->points[index[1]].y, input->points[index[1]].z);
        Eigen::Vector3f pt3(input->points[index[2]].x, input->points[index[2]].y, input->points[index[2]].z);
        
        Eigen::Vector3f vecA = pt2 - pt1;
        Eigen::Vector3f vecB = pt3 - pt1; 
        Eigen::Vector3f vecC = vecA.cross(vecB);
        vecC = vecC / vecC.norm();
        Eigen::Vector3f vec(vecC(0) * pt2[0], vecC(1) * pt2[1], vecC(2) * pt2[2]);
        double k = -vec.sum();

        Eigen::VectorXf plane_eq(4);
        plane_eq(0) = vecC(0);
        plane_eq(1) = vecC(1);
        plane_eq(2) = vecC(2);
        plane_eq(3) = k;

        Eigen::MatrixXf M = input->getMatrixXfMap(3,4,0);
        double dist_denominator = plane_eq(0)*plane_eq(0) + plane_eq(1)*plane_eq(1) +  plane_eq(2)*plane_eq(2);
        Eigen::VectorXf plan_M_0 = plane_eq(0)*M.row(0);
        Eigen::VectorXf plan_M_1 = plane_eq(1)*M.row(1);
        Eigen::VectorXf plan_M_2 = plane_eq(2)*M.row(2);
        Eigen::VectorXf dist_numerator = plan_M_0 + plan_M_1 + plan_M_2; 
        dist_numerator = dist_numerator.array() + plane_eq(3);
        Eigen::VectorXf dist_pt = dist_numerator/std::sqrt(dist_denominator);

        dist_pt = dist_pt.array().abs();
        Eigen::VectorXf a1 = M.row(0);
        Eigen::VectorXf a2 = M.row(1);
        Eigen::VectorXf a3 = M.row(2);

        // imu: Eigen::Affine3f -> Eigen::Quaternionf -> Eigen::Vector3f
        Eigen::Matrix4f iTw_Mat = i_T_w.matrix();
        Eigen::Matrix3f iTw_Rot = iTw_Mat.block(0, 0, 3, 3);
        Eigen::Quaternionf iTw_quat(iTw_Rot);
        Eigen::Matrix3f iTw;
        iTw = iTw_quat;
        Eigen::Vector3f z_axis(0, 0, 1);
        Eigen::Vector3f z_axis_transformed = iTw * z_axis;


        // Angle between two vectors
        double z_x = z_axis_transformed[0];
        double z_y = z_axis_transformed[1];
        double z_z = z_axis_transformed[2];

        int pushidx = 0;
        Eigen::VectorXi pt_id_inliers(0);
        for(int j = 0; j < dist_pt.size(); j++)
        {
            Eigen::Vector3f nn(normal->points[j].normal_x, normal->points[j].normal_y, normal->points[j].normal_z);
            float dot = z_axis.dot(nn);
            dot = ( dot < -1.0 ? -1.0 : ( dot > 1.0 ? 1.0 : dot ) );
            double angle = std::acos( dot );
            
            if(dist_pt(j) <= fSampling_threshold_ && a3(j) > fHeight_roi_min_ && a3(j) < fHeight_roi_max_ && angle*180/M_PI < 30 )
            {
                int pt_id_inliers_size = pt_id_inliers.size();
                pt_id_inliers.conservativeResize(pt_id_inliers_size + 1);
                pt_id_inliers(pt_id_inliers_size) = j;
            }
        }
        if(pt_id_inliers.size() > best_inliers.size())
        {
            best_eq = plane_eq;
            best_inliers = pt_id_inliers;
        }
        inliers = best_inliers;
        equation = best_eq;

		setOfRanSacInlierIndex->push_back(inliers); 

    }

    for(int ii = 0; ii < inliers.size(); ii++)
    {
        pcl_indices->indices.push_back(inliers[ii]);
    }
    
    pcl::ExtractIndices<pcl::PointXYZ> extraction;
    extraction.setInputCloud (input);
    extraction.setIndices (pcl_indices);
    extraction.setNegative (false);
    extraction.filter (*out);

    pcl::ExtractIndices<pcl::Normal> extractionNormal;
    extractionNormal.setInputCloud (normal);
    extractionNormal.setIndices (pcl_indices);
    extractionNormal.setNegative (false);
    extractionNormal.filter (*normal_ransac);

    model_eq->at(0) = equation(0);
    model_eq->at(1) = equation(1); 
    model_eq->at(2) = equation(2); 
    model_eq->at(3) = equation(3); 
}


void PlaneEstimationClass::staticSubscriptionCallback(const tf2_msgs::TFMessageConstPtr& msg)
{
	subscriptionCallbackImpl(msg, true);
}


void PlaneEstimationClass::subscriptionCallbackImpl(const tf2_msgs::TFMessage::ConstPtr msg, bool is_static)
{
	const tf2_msgs::TFMessage& msg_in = *msg;
	std::map<std::string, std::string> tf_link_list;
	for (unsigned int i = 0; i < msg_in.transforms.size(); i++)
	{
		geometry_msgs::TransformStamped tf_temp = msg_in.transforms[i];
		tf_link_list.insert(std::pair<std::string, std::string>(msg_in.transforms[i].header.frame_id, msg_in.transforms[i].child_frame_id));
	}	
}


void PlaneEstimationClass::imageCallback(const sensor_msgs::ImageConstPtr msg)
{
    cv_bridge::CvImagePtr cv_ptr;
    cv_ptr = cv_bridge::toCvCopy(msg, sensor_msgs::image_encodings::RGB8);
	this->color_frame_ = cv_ptr->image.clone();
	color_optical_link_name_ = msg->header.frame_id;
}


void PlaneEstimationClass::orientationFilterCallback(const geometry_msgs::Vector3StampedConstPtr msg)
{
	this->roll_ = msg->vector.x;
	this->pitch_ = msg->vector.y;
	this->yaw_ = msg->vector.z;
	imu_optical_link_name_ = msg->header.frame_id;
}


void PlaneEstimationClass::extrinsicCallback(const realsense2_camera::Extrinsics::ConstPtr msg)
{
    if (msg == NULL)
	{
	}
    else
	{
		depth_to_color_extrinsics_pos_.assign(3, 0.f);
		depth_to_color_extrinsics_rot_.assign(9, 0.f);	
		depth_to_color_extrinsics_pos_.assign(3, 0.f);
		depth_to_color_extrinsics_rot_.assign(9, 0.f);
		depth_to_color_extrinsics_pos_.at(0) = msg->translation[0];
		depth_to_color_extrinsics_pos_.at(1) = msg->translation[1];
		depth_to_color_extrinsics_pos_.at(2) = msg->translation[2];
		depth_to_color_extrinsics_rot_.at(0) = msg->rotation[0];
		depth_to_color_extrinsics_rot_.at(1) = msg->rotation[1];
		depth_to_color_extrinsics_rot_.at(2) = msg->rotation[2];
		depth_to_color_extrinsics_rot_.at(3) = msg->rotation[3];
		depth_to_color_extrinsics_rot_.at(4) = msg->rotation[4];
		depth_to_color_extrinsics_rot_.at(5) = msg->rotation[5];
		depth_to_color_extrinsics_rot_.at(6) = msg->rotation[6];
		depth_to_color_extrinsics_rot_.at(7) = msg->rotation[7];
		depth_to_color_extrinsics_rot_.at(8) = msg->rotation[8];
	}
}


void PlaneEstimationClass::cameraInfoCallback(const sensor_msgs::CameraInfo::ConstPtr msg)
{
    if (msg == NULL)
	{
	}
    else
	{
		color_intrinsics_d_.assign(5, 0.f);
		color_intrinsics_k_.assign(9, 0.f);
		color_intrinsics_d_.at(0) = msg->D[0];
		color_intrinsics_d_.at(1) = msg->D[1];
		color_intrinsics_d_.at(2) = msg->D[2];
		color_intrinsics_d_.at(3) = msg->D[3];
		color_intrinsics_d_.at(4) = msg->D[4];
		color_intrinsics_k_.at(0) = msg->K[0];
		color_intrinsics_k_.at(1) = msg->K[1];
		color_intrinsics_k_.at(2) = msg->K[2];
		color_intrinsics_k_.at(3) = msg->K[3];
		color_intrinsics_k_.at(4) = msg->K[4];
		color_intrinsics_k_.at(5) = msg->K[5];
		color_intrinsics_k_.at(6) = msg->K[6];
		color_intrinsics_k_.at(7) = msg->K[7];
		color_intrinsics_k_.at(8) = msg->K[8];
		color_distortion_model_ = msg->distortion_model;
	}
}


void PlaneEstimationClass::pointCloudCallback(const sensor_msgs::PointCloud2::ConstPtr& msg)
{
	depth_optical_link_name_ = msg->header.frame_id;
    pcl_conversions::toPCL(*msg, points_);

}


void PlaneEstimationClass::selectionMaxCluster(pcl::PointCloud<pcl::PointXYZ>::Ptr inCloud, pcl::PointCloud<pcl::PointXYZ>::Ptr clusteredCloud)
{
	pcl::search::KdTree<pcl::PointXYZ>::Ptr tree (new pcl::search::KdTree<pcl::PointXYZ>());
	pcl::PointCloud<pcl::PointXYZ>::Ptr points_normal_robot2 (new pcl::PointCloud<pcl::PointXYZ>);
	tree->setInputCloud (inCloud);
	std::vector<pcl::PointIndices> cluster_indices;
	pcl::EuclideanClusterExtraction<pcl::PointXYZ> ec;
	ec.setClusterTolerance (0.02); // 2cm
	ec.setMinClusterSize (200);
	ec.setMaxClusterSize (25000);
	ec.setSearchMethod (tree);
	ec.setInputCloud (inCloud);
	ec.extract (cluster_indices);

	int j = 0; std::vector<int> numCluster;
	pcl::PointCloud<pcl::PointXYZ>::Ptr cloud (new pcl::PointCloud<pcl::PointXYZ>);
	for (std::vector<pcl::PointIndices>::const_iterator it = cluster_indices.begin (); it != cluster_indices.end (); ++it)
	{
		pcl::PointCloud<pcl::PointXYZ>::Ptr cloudTemp (new pcl::PointCloud<pcl::PointXYZ>);
		for (const auto& idx : it->indices)
		{
			cloudTemp->push_back ((*inCloud)[idx]);
		}
		numCluster.push_back(cloudTemp->size ());
	}

	pcl::PointCloud<pcl::PointXYZ>::Ptr cloud_cluster (new pcl::PointCloud<pcl::PointXYZ>);
	int maxIndex = max_element(numCluster.begin(), numCluster.end()) - numCluster.begin();
	for (std::vector<pcl::PointIndices>::const_iterator it = cluster_indices.begin (); it != cluster_indices.end (); ++it)
	{
		if(j == maxIndex)
		{
			for (const auto& idx : it->indices)
			{
				cloud_cluster->push_back ((*inCloud)[idx]);
			}
			cloud_cluster->width = cloud_cluster->size ();
			cloud_cluster->height = 1;
			cloud_cluster->is_dense = true;
		}
		j++;
	}
    pcl::copyPointCloud(*cloud_cluster, *clusteredCloud);
}


void PlaneEstimationClass::planeEstimationCallback(const std_msgs::Bool::ConstPtr& msg)
{
    using std::chrono::high_resolution_clock;
    using std::chrono::duration_cast;
    using std::chrono::duration;
    using std::chrono::milliseconds;

    auto t1 = high_resolution_clock::now();
	robot_vision::PlaneEstimation pub_msg;
	std::vector<float> estPose(3, 0.f);
	this->planeEstimation(pub_msg);
    auto t2 = high_resolution_clock::now();
    auto ms_int = duration_cast<milliseconds>(t2 - t1);
    duration<double, std::milli> ms_double = t2 - t1;
	estimation_pub_.publish(pub_msg);
}


void PlaneEstimationClass::projectionPointsOnImage(cv::Mat &img, pcl::PointCloud<pcl::PointXYZ>::Ptr pts, int color)
{
	double point_x, point_y, point_z; 
	float pixels[2], to_point[3], from_point[3];
	int img_w = img.cols;
	int img_h = img.rows;

	for(int i = 0; i < pts->size(); i++)
	{
		pcl::PointXYZ point = pts->at(i);
		from_point[0] = static_cast<float>(point.x);
		from_point[1] = static_cast<float>(point.y);
		from_point[2] = static_cast<float>(point.z);

		this->transformPointToPoint(to_point, &depth_to_color_extrinsics_pos_, &depth_to_color_extrinsics_rot_, from_point);
		this->projectPointToPixel(pixels, &color_distortion_model_, &color_intrinsics_d_, &color_intrinsics_k_, to_point);

		float a1 = pixels[0];
		float a2 = pixels[1];
		
		if(a1 > 0 && a1 < img_w && a2 > 0 && a2 < img_h)
		{
			if(color == 0)
			{
				cv::circle( img, cv::Point( a1, a2 ), 2, cv::Scalar( 0, 0, 255 ), -1);        
			}
			if(color == 1)
			{
				cv::circle( img, cv::Point( a1, a2 ), 2, cv::Scalar( 0, 255, 0 ), -1);        				
			}
			if(color == 2)
			{
				cv::circle( img, cv::Point( a1, a2 ), 5, cv::Scalar( 255, 0, 0 ), -1);        				
			}			
		}
	}
}


void PlaneEstimationClass::projectionPointsOnImage(cv::Mat &img, pcl::PointXYZ pts, int color)
{
	double point_x, point_y, point_z; 
	float pixels[2], to_point[3], from_point[3];
	int img_w = img.cols;
	int img_h = img.rows;

	from_point[0] = static_cast<float>(pts.x);
	from_point[1] = static_cast<float>(pts.y);
	from_point[2] = static_cast<float>(pts.z);

	this->transformPointToPoint(to_point, &depth_to_color_extrinsics_pos_, &depth_to_color_extrinsics_rot_, from_point);
	this->projectPointToPixel(pixels, &color_distortion_model_, &color_intrinsics_d_, &color_intrinsics_k_, to_point);

	float a1 = pixels[0];
	float a2 = pixels[1];
	
	if(a1 > 0 && a1 < img_w && a2 > 0 && a2 < img_h)
	{
		if(color == 0)
		{
			cv::circle( img, cv::Point( a1, a2 ), 2, cv::Scalar( 0, 0, 255 ), -1);        
		}
		if(color == 1)
		{
			cv::circle( img, cv::Point( a1, a2 ), 2, cv::Scalar( 0, 255, 0 ), -1);        				
		}
		if(color == 2)
		{
			cv::circle( img, cv::Point( a1, a2 ), 10, cv::Scalar( 255, 0, 0 ), -1);        				
		}
	}
}


void PlaneEstimationClass::planeEstimation(robot_vision::PlaneEstimation &estPose)
{
	float roll = M_PI_2 + this->pitch_;
	float pitch = (-1) * this->roll_;
	float yaw = 0.f;	

	cv::Mat imageTest;
	this->color_frame_.copyTo(imageTest);
	cv::cvtColor(imageTest, imageTest, cv::COLOR_BGR2RGB);

    pcl::PointCloud<pcl::PointXYZ>::Ptr cloud(new pcl::PointCloud<pcl::PointXYZ>());
    pcl::fromPCLPointCloud2(points_, *cloud);

	// Cutting off point at a specific distance
	pcl::PointCloud<pcl::PointXYZ>::Ptr cloud_filtered_dist(new pcl::PointCloud<pcl::PointXYZ>());
	pcl::PassThrough<pcl::PointXYZ> pass;
	pass.setInputCloud (cloud);
	pass.setFilterFieldName ("z");
	pass.setFilterLimits (0.0, fpoint_z_limit_);
	pass.filter (*cloud_filtered_dist);

	// Downsize to a voxel grid
	pcl::PointCloud<pcl::PointXYZ>::Ptr cloud_filtered_sparse(new pcl::PointCloud<pcl::PointXYZ>());
	pcl::VoxelGrid<pcl::PointXYZ> sor;
	sor.setInputCloud(cloud_filtered_dist);
	sor.setLeafSize(0.01f, 0.01f, 0.01f);
	sor.filter(*cloud_filtered_sparse);

	// Create the filtering object
	pcl::PointCloud<pcl::PointXYZ>::Ptr cloud_filtered_tree(new pcl::PointCloud<pcl::PointXYZ>());
	pcl::StatisticalOutlierRemoval<pcl::PointXYZ> sor2;
	sor2.setInputCloud (cloud_filtered_sparse);
	sor2.setMeanK (100);
	sor2.setStddevMulThresh (0.05);
	sor2.filter (*cloud_filtered_tree);

	// TF: camera to world
	Eigen::Affine3f r = createRotationMatrix(90, 0, 90);
	Eigen::Affine3f t(Eigen::Translation3f(Eigen::Vector3f(0, 0, 0)));

	// TF: base -> camera
	Eigen::Affine3f T_b2c = Eigen::Affine3f::Identity();
	T_b2c.translation() << fTF_b2c_pos_x_, fTF_b2c_pos_y_, fTF_b2c_pos_z_;
	Eigen::Quaternionf R_b2c_quat;
	R_b2c_quat.w() = fTF_b2c_quat_w_;
	R_b2c_quat.x() = fTF_b2c_quat_x_;
	R_b2c_quat.y() = fTF_b2c_quat_y_;
	R_b2c_quat.z() = fTF_b2c_quat_z_;
	Eigen::Matrix3f R_b2c = R_b2c_quat.toRotationMatrix();

	// TF: IMU -> camera then camera -> world
	r = createRotationMatrix(-(pitch - M_PI_2)*180/M_PI, 0, (roll - M_PI_2)*180/M_PI);
	t = Eigen::Translation3f(Eigen::Vector3f(0, 0, 0));
	Eigen::Affine3f T_i2c = (t * r);

	// TF: camera (0-roll and 0-pitch) -> manipulator
	r = createRotationMatrix(0, 0, fTF_b2c_rot_z_manual_);
	t = Eigen::Translation3f(Eigen::Vector3f(fTF_b2c_pos_x_manual_, fTF_b2c_pos_y_manual_, fTF_b2c_pos_z_manual_));
	Eigen::Affine3f T_coo2b = (t * r);	

	// TF: optical -> camera
	r = createRotationMatrix(-90, 0, -90);
	t = Eigen::Translation3f(Eigen::Vector3f(0, 0, 0));
	Eigen::Affine3f T_c2r = (t * r);
	Eigen::Affine3f T_i2r = T_c2r * T_i2c;
	Eigen::Affine3f T_r2i = T_i2r.inverse();
	Eigen::Affine3f T_b2coo = T_coo2b.inverse();

	// Executing the transformation
	pcl::PointCloud<pcl::PointXYZ>::Ptr points_imu(new pcl::PointCloud<pcl::PointXYZ>());
	pcl::PointCloud<pcl::PointXYZ>::Ptr points_camera(new pcl::PointCloud<pcl::PointXYZ>());
	pcl::PointCloud<pcl::PointXYZ>::Ptr points_camera_ransac(new pcl::PointCloud<pcl::PointXYZ>());
	pcl::PointCloud<pcl::PointXYZ>::Ptr points_robot(new pcl::PointCloud<pcl::PointXYZ>());
	pcl::PointCloud<pcl::PointXYZ>::Ptr cloud_robot(new pcl::PointCloud<pcl::PointXYZ>());
	pcl::transformPointCloud(*cloud_filtered_tree, *points_imu, T_i2c);
	pcl::transformPointCloud(*cloud_filtered_tree, *points_robot, T_i2r);
	pcl::transformPointCloud(*cloud, *cloud_robot, T_i2r);

	// Get surface normal
	pcl::NormalEstimation<pcl::PointXYZ, pcl::Normal> ne;
	pcl::search::KdTree<pcl::PointXYZ>::Ptr tree (new pcl::search::KdTree<pcl::PointXYZ>());
	pcl::PointCloud<pcl::Normal>::Ptr points_normal_robot (new pcl::PointCloud<pcl::Normal>);
	ne.setInputCloud (points_robot);
	ne.setSearchMethod (tree);
	ne.setRadiusSearch (0.03);
	ne.compute (*points_normal_robot);

	// get sampling points
	bool bRansacLog_ = true;
	std::vector<Eigen::VectorXi> setOfRanSacInlierIndex;
	pcl::PointCloud<pcl::PointXYZ>::Ptr points_robot_ransac (new pcl::PointCloud<pcl::PointXYZ>());
	pcl::PointCloud<pcl::Normal>::Ptr normal_robot_ransac (new pcl::PointCloud<pcl::Normal>);
	std::vector<float> plane_model(4, 0.0);
	if(points_imu->size() > 100)
	{
		this->sampling(points_robot, points_normal_robot, T_i2c, points_robot_ransac, normal_robot_ransac, &plane_model, bRansacLog_, &setOfRanSacInlierIndex);
	}

	this->selectionMaxCluster(points_robot_ransac, points_robot_ransac);
	pcl::transformPointCloud(*points_robot_ransac, *points_camera_ransac, T_r2i);
	pcl::transformPointCloud(*points_robot, *points_camera, T_r2i);

	// Show camera as coordinate system
	pcl::ModelCoefficients coefficients;
	coefficients.values.resize(4);
	coefficients.values[0] = plane_model.at(0);
	coefficients.values[1] = plane_model.at(1);
	coefficients.values[2] = plane_model.at(2);
	coefficients.values[3] = plane_model.at(3);

	// Point representation in Rviz, Publish TF for sensor
	tf::Transform transform_point;
	tf::Quaternion q_point;
	q_point.setRPY(-M_PI_2, 0,  -M_PI_2);
	transform_point.setOrigin( tf::Vector3(0.0, 0.0, 1.5) );
	transform_point.setRotation(q_point);
	tf_point_.sendTransform(tf::StampedTransform(transform_point, ros::Time::now(), depth_optical_link_name_, sensor_name_ + "_point"));

	// Sensor coord. representation in Rviz, Publish TF for sensor
	tf::Transform transform_axis;
	tf::Quaternion q_axis;
	q_axis.setRPY(roll_-M_PI_2, pitch_-M_PI_2, 0);
	transform_axis.setOrigin( tf::Vector3(0.0, 0.0, 1.5) );
	transform_axis.setRotation(q_axis);
	tf_sensor_.sendTransform(tf::StampedTransform(transform_axis, ros::Time::now(), depth_optical_link_name_, sensor_name_ + "_robot_attitude"));

	// Publishing pointcloud and images
	bDebug_ = true;
	if(bDebug_)
	{
		if(cloud_filtered_tree->size() > 0 && points_camera_ransac->size() > 0 && depth_to_color_extrinsics_pos_.size() > 0)
		{
			sensor_msgs::PointCloud2 cloud_msg;
			pcl::PCLPointCloud2 cloud_pclCloud;
			pcl::toPCLPointCloud2( *cloud, cloud_pclCloud ); //
			pcl_conversions::fromPCL(cloud_pclCloud, cloud_msg);
			cloud_msg.header.frame_id = depth_optical_link_name_;
			points_camera_pub_.publish (cloud_msg);

			sensor_msgs::PointCloud2 points_robot_msg;
			pcl::PCLPointCloud2 points_robot_pclCloud;
			pcl::toPCLPointCloud2( *points_robot, points_robot_pclCloud ); //
			pcl_conversions::fromPCL(points_robot_pclCloud, points_robot_msg);
			points_robot_msg.header.frame_id = depth_optical_link_name_;
			points_robot_pub_.publish (points_robot_msg);

			sensor_msgs::PointCloud2 points_robot_ransac_msg;
			pcl::PCLPointCloud2 points_robot_ransac_pclCloud;
			pcl::toPCLPointCloud2( *points_robot_ransac, points_robot_ransac_pclCloud );
			pcl_conversions::fromPCL(points_robot_ransac_pclCloud, points_robot_ransac_msg);
			points_robot_ransac_msg.header.frame_id = depth_optical_link_name_;
			points_robot_ransac_pub_.publish (points_robot_ransac_msg);

			pcl::PointXYZ centre_base;
			pcl::PointXYZ centre_cam;
			pcl::computeCentroid(*points_robot_ransac, centre_base);
			pcl::computeCentroid(*points_camera_ransac, centre_cam);
			this->projectionPointsOnImage( imageTest, cloud_filtered_tree, 0 );
			this->projectionPointsOnImage( imageTest, points_camera_ransac, 1 );
			this->projectionPointsOnImage( imageTest, centre_cam, 2 );

			cv_bridge::CvImage img_bridge;
			sensor_msgs::Image img_msg; 
			std_msgs::Header header; 
			header.stamp = ros::Time::now(); 
			img_bridge = cv_bridge::CvImage(header, sensor_msgs::image_encodings::BGR8, imageTest);
			img_bridge.toImageMsg(img_msg);
			pubImage_.publish(img_msg);

			Eigen::Vector3f centre_in_base_(centre_base.x, centre_base.y, centre_base.z);
			auto centre_in_manibase_ = T_b2coo*centre_in_base_;
			centre_base.x = centre_in_manibase_(0);
			centre_base.y = centre_in_manibase_(1);		
			centre_base.z = centre_in_manibase_(2);
			std::cout << "centre_in_base_: " << centre_in_base_ << std::endl;
			std::cout << "centre_in_manibase_: " << centre_in_manibase_ << std::endl;

			estPose.header.seq = 1;
			estPose.header.stamp = ros::Time::now();
			estPose.header.frame_id = "world";
			estPose.estimation.data = true;
			estPose.pose.pose.position.x = centre_base.x;
			estPose.pose.pose.position.y = centre_base.y;
			estPose.pose.pose.position.z = centre_base.z;
			estPose.pose.pose.orientation.w = 1;
			estPose.pose.pose.orientation.x = 0;
			estPose.pose.pose.orientation.y = 0;
			estPose.pose.pose.orientation.z = 0;
			for(int i = 0; i < 36; i++)
			{
				estPose.pose.covariance[i] = 1;
			}
		}
		else
		{
			estPose.header.seq = 1;
			estPose.header.stamp = ros::Time::now();
			estPose.header.frame_id = "world";
			estPose.estimation.data = false;
			estPose.pose.pose.position.x = 0;
			estPose.pose.pose.position.y = 0;
			estPose.pose.pose.position.z = 0;
			estPose.pose.pose.orientation.w = 0;
			estPose.pose.pose.orientation.x = 0;
			estPose.pose.pose.orientation.y = 0;
			estPose.pose.pose.orientation.z = 0;
			for(int i = 0; i < 36; i++)
			{
				estPose.pose.covariance[i] = 0;
			}
		}
	}
}


}
