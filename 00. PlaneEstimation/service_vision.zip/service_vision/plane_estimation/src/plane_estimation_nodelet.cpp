#include "plane_estimation_nodelet.h"
#include <nodelet/nodelet.h>
#include <pluginlib/class_list_macros.h>

namespace vision_nodelet_ns
{
PlaneEstimationNodelet::PlaneEstimationNodelet()
{
  ROS_INFO("PlaneEstimationNodelet Constructor");
}

PlaneEstimationNodelet::~PlaneEstimationNodelet()
{
  ROS_INFO("PlaneEstimationNodelet Destructor");
}

void PlaneEstimationNodelet::onInit()
{
    ns.init(getNodeHandle(), getPrivateNodeHandle());
    NODELET_INFO("PlaneEstimationNodelet - %s", __FUNCTION__);
}
}

PLUGINLIB_EXPORT_CLASS(vision_nodelet_ns::PlaneEstimationNodelet, nodelet::Nodelet)
