#include "orientation_filter_nodelet.h"
#include <pluginlib/class_list_macros.h>

namespace vision_nodelet_ns
{
OrientationFilterNodelet::OrientationFilterNodelet()
{
  ROS_INFO("OrientationFilterNodelet Constructor");
}

OrientationFilterNodelet::~OrientationFilterNodelet()
{
  ROS_INFO("OrientationFilterNodelet Destructor");
}

void OrientationFilterNodelet::onInit()
{
    ns.init(getNodeHandle(), getPrivateNodeHandle());
    NODELET_INFO("OrientationFilterNodelet - %s", __FUNCTION__);
}
}

PLUGINLIB_EXPORT_CLASS(vision_nodelet_ns::OrientationFilterNodelet, nodelet::Nodelet)
