#include "orientation_filter_class.h"

using namespace std;

namespace vision_nodelet_ns
{

OrientationFilterClass::OrientationFilterClass()
{
	// this->reset();
}

OrientationFilterClass::~OrientationFilterClass()
{
}

void OrientationFilterClass::init(ros::NodeHandle &nh, ros::NodeHandle &private_nh)
{
	imu_gyro_sub = nh.subscribe("/camera/imu/gyro", 1000, &OrientationFilterClass::ImuGyroCallback, this);
	imu_acc_sub = nh.subscribe("/camera/imu/acc", 1000, &OrientationFilterClass::ImuAccCallback, this);
}

void OrientationFilterClass::ImuGyroCallback(const sensor_msgs::Imu::ConstPtr& msg)
{
}

void OrientationFilterClass::ImuAccCallback(const sensor_msgs::Imu::ConstPtr& msg)
{
}


void OrientationFilterClass::timerCallback(const ros::TimerEvent&)
{

}

void OrientationFilterClass::reset()
{
	calibrationUpdates = 0;

	minX = 1000;
	minY = 1000;
	minZ = 1000;
	maxX = -1000;
	maxY = -1000;
	maxZ = -1000;

	x = 0;
	y = 0;
	z = 0;

	isSet = false;
}

bool OrientationFilterClass::update(double gx, double gy, double gz)
{
	if (calibrationUpdates < 50)
	{   
		maxX = std::max(gx, maxX);
		maxY = std::max(gy, maxY);
		maxZ = std::max(gz, maxZ);

		minX = std::min(gx, minX);
		minY = std::min(gy, minY);
		minZ = std::min(gz, minZ);

		calibrationUpdates++;
		return false;
	}
	else if (calibrationUpdates == 50)
	{
		x = (maxX + minX)/2.0;
		y = (maxY + minY)/2.0;
		z = (maxZ + minZ)/2.0;
		calibrationUpdates++;

		isSet = true;

		return true;
	}
	else
	{
		return false;
	}
}

}
