#ifndef SAMPLE_NODELET_CLASS_SRC_SAMPLE_NODELET_CLASS2_H_
#define SAMPLE_NODELET_CLASS_SRC_SAMPLE_NODELET_CLASS2_H_

#include <nodelet/nodelet.h>
#include "plane_estimation_class.h"

namespace vision_nodelet_ns
{
    
class PlaneEstimationNodelet : public nodelet::Nodelet
{

private:
	PlaneEstimationClass ns;    

public:
    PlaneEstimationNodelet();
    ~PlaneEstimationNodelet();

    virtual void onInit();

};

}

#endif
