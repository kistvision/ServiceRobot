#pragma once

#include <ros/ros.h>
#include <std_msgs/String.h>
#include <sensor_msgs/Imu.h>
#include <librealsense2/rs.hpp>


namespace vision_nodelet_ns
{

class OrientationFilterClass
{
	
private:
	ros::Publisher pub;
	std::string param;
	ros::Timer timer;
	ros::Subscriber imu_gyro_sub;
	ros::Subscriber imu_acc_sub;
	
public:
	OrientationFilterClass();
   ~OrientationFilterClass();
	
    void init(ros::NodeHandle &nh, ros::NodeHandle &private_nh);
	void reset();
	bool update(double gx, double gy, double gz);	
	void timerCallback(const ros::TimerEvent&);
	void ImuGyroCallback(const sensor_msgs::Imu::ConstPtr& msg);
	void ImuAccCallback(const sensor_msgs::Imu::ConstPtr& msg);


private:
	int calibrationUpdates;
	double minX, maxX;
	double minY, maxY;
	double minZ, maxZ;


public:
	bool isSet;
	double x;
	double y;
	double z;


};

};
