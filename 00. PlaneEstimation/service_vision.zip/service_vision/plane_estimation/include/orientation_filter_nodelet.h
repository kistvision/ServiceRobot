#ifndef SAMPLE_NODELET_CLASS_SRC_SAMPLE_NODELET_CLASS_H_
#define SAMPLE_NODELET_CLASS_SRC_SAMPLE_NODELET_CLASS_H_


#include <nodelet/nodelet.h>
#include "orientation_filter_class.h"


namespace vision_nodelet_ns
{

class OrientationFilterNodelet : public nodelet::Nodelet
{
private:
	OrientationFilterClass ns;    
    
public:
    OrientationFilterNodelet();
    ~OrientationFilterNodelet();

    virtual void onInit();
};

}

#endif
