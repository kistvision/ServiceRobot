#pragma once

#include <random>
#include <chrono>
#include <boost/bind.hpp>
#include "nodelet/nodelet.h"
#include <ros/ros.h>
#include <std_msgs/String.h>
#include <std_msgs/Bool.h>
#include <sensor_msgs/Imu.h>
#include <sensor_msgs/Image.h>
#include <sensor_msgs/image_encodings.h>
#include <sensor_msgs/PointCloud2.h>
#include <geometry_msgs/Vector3Stamped.h>
#include <image_transport/image_transport.h>
#include <tf/tf.h>
#include <tf/transform_broadcaster.h>
#include <tf_conversions/tf_eigen.h>
#include <tf2_msgs/TFMessage.h>
#include <tf2_ros/transform_listener.h>
#include <realsense2_camera/Extrinsics.h>
#include <robot_vision/PlaneEstimation.h>
#include <eigen_conversions/eigen_msg.h>
#include <rviz_visual_tools/rviz_visual_tools.h>
#include <pcl/point_types.h>
#include <pcl/filters/passthrough.h>
#include <pcl/filters/crop_box.h>
#include <pcl/filters/voxel_grid.h>
#include <pcl/io/pcd_io.h>
#include <pcl/visualization/cloud_viewer.h>
#include <pcl_conversions/pcl_conversions.h>
#include <pcl/point_cloud.h>
#include <pcl/features/normal_3d.h>
#include <pcl/visualization/pcl_visualizer.h>
#include <pcl/common/common_headers.h>
#include <pcl/io/pcd_io.h>
#include <pcl/console/parse.h>
#include <pcl/search/kdtree.h>
#include <pcl/filters/extract_indices.h>
#include <pcl/filters/statistical_outlier_removal.h>
#include <pcl/common/impl/centroid.hpp>
#include <pcl/segmentation/extract_clusters.h>
#include <cv_bridge/cv_bridge.h>
#include <opencv2/imgproc/imgproc.hpp>
#include <opencv2/highgui.hpp>
#include <opencv2/core.hpp>


namespace vision_nodelet_ns
{

class PlaneEstimationClass
{

public:
	PlaneEstimationClass();
   ~PlaneEstimationClass();
	
    void init(ros::NodeHandle &nh, ros::NodeHandle &private_nh);
	void imageCallback(const sensor_msgs::ImageConstPtr msg);
	void orientationFilterCallback(const geometry_msgs::Vector3StampedConstPtr msg);
	void pointCloudCallback(const sensor_msgs::PointCloud2::ConstPtr& msg);
	void planeEstimationCallback(const std_msgs::Bool::ConstPtr& msg);
	void extrinsicCallback(const realsense2_camera::Extrinsics::ConstPtr msg);
	void cameraInfoCallback(const sensor_msgs::CameraInfo::ConstPtr msg);
	void staticSubscriptionCallback(const tf2_msgs::TFMessageConstPtr& msg);
	void subscriptionCallbackImpl(const tf2_msgs::TFMessage::ConstPtr msg, bool is_static);
	void planeEstimation(robot_vision::PlaneEstimation &estPose);
	void selectionMaxCluster(pcl::PointCloud<pcl::PointXYZ>::Ptr inCloud, pcl::PointCloud<pcl::PointXYZ>::Ptr clusteredCloud);
	void projectionPointsOnImage(cv::Mat &img, pcl::PointCloud<pcl::PointXYZ>::Ptr pts, int color);
	void projectionPointsOnImage(cv::Mat &img, pcl::PointXYZ pts, int color);
	void projectPointToPixel(float pixel[2], std::string *distortion_model, std::vector<float> *intrin_d, std::vector<float> *intrin_k, float point[3]);
	void transformPointToPoint(float to_point[3], std::vector<float> *pos, std::vector<float> *rot, float from_point[3]);
	void sampling(pcl::PointCloud<pcl::PointXYZ>::Ptr input, pcl::PointCloud<pcl::Normal>::Ptr normal, Eigen::Affine3f i_T_w, pcl::PointCloud<pcl::PointXYZ>::Ptr out, pcl::PointCloud<pcl::Normal>::Ptr normal_ransac, std::vector<float> *model_eq, bool bRansacLog_, std::vector<Eigen::VectorXi> *setOfRanSacInlierIndex);	
	Eigen::Affine3f createRotationMatrix(double ax, double ay, double az);

private:
	bool dDebug_;
	bool bDebug_;
	float fHeight_roi_min_, fHeight_roi_max_;
	float fSampling_threshold_;
	float fpoint_z_limit_;
	float fTF_b2c_pos_x_, fTF_b2c_pos_y_, fTF_b2c_pos_z_;
	float fTF_b2c_quat_w_, fTF_b2c_quat_x_, fTF_b2c_quat_y_, fTF_b2c_quat_z_;
	float fTF_b2c_pos_x_manual_, fTF_b2c_pos_y_manual_, fTF_b2c_pos_z_manual_, fTF_b2c_rot_z_manual_;
	int nSampling_iteration_;
	float roll_, pitch_, yaw_;
	std::vector<float> depth_to_color_extrinsics_pos_;
	std::vector<float> depth_to_color_extrinsics_rot_;
	std::vector<float> color_intrinsics_k_;
	std::vector<float> color_intrinsics_d_;
	std::string color_distortion_model_;
	std::string color_optical_link_name_;
	std::string depth_optical_link_name_;
	std::string imu_optical_link_name_;
	std::string sensor_name_;

	image_transport::Publisher pubImage_;
	ros::Publisher points_camera_pub_;
	ros::Publisher points_robot_pub_;
	ros::Publisher points_robot_ransac_pub_;
	ros::Publisher robot_cmd_pub_;
	ros::Publisher estimation_pub_;
	ros::Publisher estimation_pub2_;
	ros::Subscriber orientation_filter_sub_;
	ros::Subscriber plane_estimation_sub_;
	ros::Subscriber single_plane_estimation_sub_;
	ros::Subscriber image_sub_;
	ros::Subscriber points_sub_;
	ros::Subscriber tf_static_sub_;
	ros::Subscriber extrinsic_sub_;
	ros::Subscriber camerainfo_sub_;
	ros::Subscriber status_robot_sub_;
	ros::Subscriber robot_status_sub_;

	tf::TransformBroadcaster tf_point_;
    tf::TransformBroadcaster tf_sensor_;
	pcl::PCLPointCloud2 points_;
	cv::Mat color_frame_;


};

};
